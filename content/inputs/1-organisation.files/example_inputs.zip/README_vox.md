# YAML format for Voxel computations

## News

An example input file is provided and named `config_vox.yml` (the name is not mandatory).
The parameter names were modified to match the ones from the update to the inputs of ARCHIMED.

The outputs names were also modified: `intercepted_energy` becomes `Ri_0_q`, `intercepted_PADir` was renamed `Ri_0_f`, and `intercepted_power` was removed. Please check that the model outputs the same units than stated in the `config_vox.yml`.

Further work is needed to simulate biophysical processes for a voxel scene as in a regular 3D scene.

## Further work

- [ ] Add the timestep duration as an output (`step_duration`);
- [ ] Add the possibility to associate each input voxel to a functional group, and then use the parameters as for a 3D application of ARCHIMED;
- [ ] Add a soil;
- [ ] Add scattering;
- [ ] Add a subdivision by wavelength;
- [ ] Add all outputs from a 3D application of ARCHIMED.
