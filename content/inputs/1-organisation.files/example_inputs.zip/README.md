# YAML format for ARCHIMED configuration files

## News

The input files were heavily modified, it includes the following changes.

### Meteo file

A **mandatory** header in YAML format is added in the meteo file to specify some properties of the site: latitude, longitude. In the CSV format, optional metadata can be written in the file (e.g. the meteo name), e.g.:

```yaml
#' name: Aquiares
#' latitude: 15.0  # in degrees (this is an in-line comment not interpreted as YAML)
#' altitude: 100.0
# This is simple comment that is not interpretted as YAML.
date;hour_start;duration;temperature;relativeHumidity;clearness;wind;atmosphereCO2_ppm
2016/06/12;12:00:00;00:30:00;25;60;0.75;1;380
```
Each line of the header specifying a YAML value starts with a `#'`, and comments are written as regular comments with a single `#`, either in-line (as for the comment in the latitude line) or on its own line (the line after altitude). This is close to the standard used in roxygen documentation.
The meteo data is then written after the header in the CSV format (either `,` or `;` separated).

### config.yml

The main configuration file (e.g. `app.properties`) now uses YAML format (e.g. `config.yml`). Several changes were made in the file too:

- all parameters were renamed using snake case instead of camel case to enhance visibility, e.g.:
```yaml
allInTurtle: true
# becomes:
all_in_turtle: true
```
- `nodes` was renamed `components`, e.g. `nodes_values` was renamed `component_values`
- `file` is renamed `scene`
- `modelsManager` is renamed `models`
- `meteoFile` is renamed `meteo`
-
```yaml
toricity: TORIC_INFINITE_BOX_TOPOLOGY
```
  This option was moved to the advanced parameters because if the user wants a simulation without toricity, he needs to increase dramatically the plot boundaries to be sure the pixel tables are large enough to sample all the objects (especially for low directions). The option is now a Boolean instead of the model name, and its default value is set to `true`:
```yaml
toricity: true
```

- Removed
 ```yaml
reducedTable: false # If set to true, the program will be less RAM-heavy but it will lose the value of height.
```
  because the model already has all the information to handle the cases (if no Z is needed, use `reducedTable: true` to optimize)

- Removed parameters `energyBalance` and `photosynthesis` because at the moment they come together. Replaced by `photosynthesis` only.

- Removed this:
  ```yaml
    latitude: 15 # [degrees]; Latitude is associated to meteo for computing the sun position
    altitude: 100 # [degrees]
  ```
  and put it as a header in the meteo file;
- `nodesValuesColumns` was renamed `component_variables`;
- `saveOnDisk` was renamed `cache_pixel_table`;
- `numberOfPixels` was removed and replaced by `pixel_size`, the pixel side length in cm.
- `exportData` was renamed `write_summary`;
- `atEachStep` was removed for now, will be re-integrated when it works, and named `integrate`. This option
- `exportNodesValues` was removed. If the component values are not needed, simply set all `component_variables` to `false`.
- `component_variables`: is now given as a YAML sequence with the name of the variable as the key and a Boolean value: `true` if we want the variable, `false` if we don't want it, e.g.:
```yaml
component_variables:
    - stepNumber: true
    - stepDuration: true
    ...
    - enb_transpir_kg_s: true
    - enb_leaf_temp_C: false
```
If a variable is not given, its default value is `false`.

- The names of the variables in `component_variables` is updated to follow a strict notation: <Name of the variable>[f|q], with f denoting a flux density, and q a quantity. For example, the latent heat flux in W m[component]-2 is a flux density, so the name of the variable would be `LE_f`. If the user wants it in quantity (J component-1 timestep-1), the variable would be `LE_q`. The incident and absorbed radiations have one more argument: the wavelength, e.g. the flux density of the absorbed radiation in the PAR is named `Ra_PAR_f` (in W m[component]-2). The new variables are:
  * Rn_f, Rn_q: Net radiation for the PAR + NIR + TIR (flux density, quantity);
  * Ri_PAR_0_[q,f], Ri_NIR_0_[q,f]: Incident radiation (also known as incoming radiation) for each wavelength except TIR, **without scattering** (order 0 light interception, coming from the direct and diffuse light from the atmosphere only);
  * Ri_PAR_[q,f], Ri_NIR_[q,f], Ri_TIR_[q,f]: Incident radiation (also known as incoming radiation) for each wavelength, **with scattering** (order 0 + order n light interception, coming from the direct and diffuse light from the atmosphere, and the other objects from the scene);
  * Ra_PAR_0_[q,f], Ra_NIR_0_[q,f]: Absorbed radiation (incident radiation minus scattered radiation) for each wavelength except TIR, **without scattering**. Note: it is a net radiation by wavelength;
  * Ra_PAR_[q,f], Ra_NIR_[q,f], Ra_TIR_[q,f]: Absorbed radiation for each wavelength, with scattering;
  * An_[q,f]: Net CO2 assimilation rate (µmol m-2 s-1) and net assimilated CO2 (µmol component-1 timestep-1, i.e. photosynthesis during the timestep) respectively;
  * Gs: stomatal conductance (mol m-2 s-1);
  * H_[q,f]: Sensible heat flux (W m[component]-2), and quantity (J component-1 timestep-1) respectively;
  * LE_[q,f]: Latent heat flux (W m[component]-2), and quantity (J component-1 timestep-1) respectively;
  * Tr_[q,f]: Transpiration flux (mm m[component]-2), and quantity (mm component-1 timestep-1) respectively;
  * T: temperature (Celsius degree);  

  > Note: The subscripts are easy to remember: q or f for quantity or flux density, and for the radiation the name of the wavelength for detailed values, and 0 if only the first order interception is needed.

- Add `opf_variables` to choose which variables are needed in the output OPFs (as for `component_variables`). NB: the user can use anchors with `component_variables` if he wants the same variables.
- `exportOPS` is renamed to `export_ops `.
- Add `opf_overwrite_variables` to choose the model behaviour in case of variables already existing in the input with the same name as the output. If `true`, overwrite input values with the output from ARCHIMED. If `false` return an error.
- Removed `plot_paving` and put it in the soil file.
- plant and soil were changed into a list of models in the `config.yml`

### Model files

* The CSV photosynthesis information file (referenced in the `Photosynthesis` column of the model manager file, e.g.`parameters.csv`) and `models.csv` are re-organized into a list of YAML files, e.g. `plant_coffee.yml` and `soil.yml`. The soil file is the same as any plant file so far (e.g. group, type, model parameters), but will be populated with new parameters soon. It is identified as a soil file if it uses the `Cobblestone` component type.
On startup, all model files are read and merged into a big model information; only the content matters, not the file names or number.
Each process is listed for each component type, and its parameter names and values are listed below, e.g.:

```yaml
Group: coffee                     # -> functional group
Type:                             # -> component types
  - Leaf:                         # -> new component (name must match OPF values)
      - Interception:             # -> Process
            - model: Translucent  # -> Name of the model used
            - transparency: 0     # -> Parameter names and values
            - optical_properties:
                - PAR: 0.15       # -> ...
                - NIR: 0.9
      - StomatalConductance:        # -> Process
            - model: Medlyn         # -> Name of the model used
            - g0: -0.03             # -> Parameter name and value
            - g1: 12                # -> Parameter name and value
[...]
```

Here we have a coffee as a functional group, and a component type called `Leaf`, for which the `Interception` process will be simulated using the `Translucent` model that has 3 parameters - the transparency, the scattering factor for the PAR, and for the NIR - all parameterized with some values. Similarly, the `StomatalConductance` process is simulated using the `Medlyn` model with two parameters (`g0` and `g1`).

Several models can be parameterized at the same time for each process using several model instances, in which case the input format is modified to:  

```yaml
[...]
      - StomatalConductance       # -> Process
        - use: Medlyn_generic     # -> Name of the model instance to use
        - Medlyn_generic:         # -> Name of a model instance (free name)
            - model: Medlyn       # -> Name of the model used in the instance
            - g0: -0.03           # -> Parameter names and values
            - g1: 12
        - Medlyn_caturra:         # -> Name of a 2nd model instance (free name)
            - model: Medlyn       # -> Name of the model used in the instance
            - g0: -0.03
            - g1: 12.5
        - Yin-Struik_caturra:     # -> Name of a 3rd model instance (free name)
            - model: Yin-Struik   # -> Name of the model used in the instance
            - g0: 0.02089956
            - a1: 0.9
            - b1: 0.15
[...]
```

Here for the conductance process, we have three model instances: `Medlyn_generic`, `Medlyn_caturra` and `Yin-Struik_caturra`. The first two model instances use the same model (i.e. Medlyn), but have a different name (`Medlyn_generic` and `Medlyn_caturra`) and different parameter values. The last one is an instance of the `Yin-Struik` model called `Yin-Struik_caturra`.
This method allows to parameterize several models or the same model with different values on the same file, and to chose only one to use. This is especially useful when dealing with different varieties in the same file. For example here "caturra" is the name of a variety.

- The interception model is revised. We only use one model name (so far, Translucent uses bilambertian optical properties), and if a Translucent model does not, the optical properties are different (eg. different scattering factors for up and down face of the leaf).
The value of the transparency is also now used as a parameter.
So now it looks like this:
  ```yaml
  Type:
    - Metamer:
        - Interception:
            - use: Translucent_1
            - Translucent_1:
                - model: Translucent
                - transparency: 0
                - optical_properties
                      - PAR: 0.15
                      - NIR: 0.9
  ```

* Add `plot_paving` here instead of in the `config.yml`

## Defaults

### Config

In the config, all parameters are mandatory, except for the hidden parameters for advanced-users.

## To do

### General

- It is not possible to simulate `energyBalance` without `photosynthesis` and vice-versa at the moment. Make it possible:
  - `energyBalance: true` and `photosynthesis: false` read Gs as a parameter from the model;
  - `energyBalance: false` and `photosynthesis: true` take Tleaf as Tair.

### OPS

The OPS file format is updated to allow one more column for the functional group, e.g.:

```yaml
# T xOrigin yOrigin zOrigin xSize ySize flat
T 0 0 0 2 2 flat

#sceneId plantId plantFileName x y z scale inclinationAzimut inclinationAngle stemTwist functionalGroup
1	1	opf/P6_Ru_ii_L2P02.opf	0		0		0	0	0	0	0 coffee
1	1	opf/P6_Ru_ii_L2P02.opf	0		0		0	0	0	0	0 elaeis
```
